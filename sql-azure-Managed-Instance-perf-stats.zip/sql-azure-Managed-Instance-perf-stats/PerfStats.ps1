# Managed Instance PerfStat Script

param(
	[Parameter(Mandatory=$true, HelpMessage="Enter the Managed Instance full name")][string]$ServerName,
	[Parameter(Mandatory=$true)][string]$Database, 
	[Parameter(Mandatory=$true)][string]$Username, 
	[Parameter(Mandatory=$true)][string]$Password,
	[Int32]$DelayInSeconds=10,
	[switch]$AzureUSGov=$false
)

# If you have included the FQDN, cut it off and use only what is before the first .
#if ($ServerName -like '*.*') {
#	$ServerName = $ServerName.Split('.')[0]
#}

# Convert seconds to hours:minutes:seconds for WAITFOR DELAY format
$seconds = $DelayInSeconds
$minutes = 0
$hours = 0

if ($seconds -ge 60) {
	$minutes = $seconds/60
	$seconds = $seconds%60
	if ($minutes -ge 60) {
		$hours = $minutes/60
		$minutes = $minutes%60
	}
}
$delayString = $hours.ToString("00") + ":" + $minutes.ToString("00") + ":" + $seconds.ToString("00")

# Add protocol, FQDN, and Port If US gov is selected use that FQDN
$serverFQDN = $ServerName #"tcp:$($ServerName).database.windows.net,1433"
#if ($AzureUSGov) {
#	$serverFQDN = "tcp:$($ServerName).database.usgovcloudapi.net,1433"
#}

$fullUsername = $Username #+ "@" + $ServerName

If (!(Test-Path "output")) {
	New-Item -Name "output" -ItemType directory | Out-Null
}

$outputFile = ".\output\$($ServerName)_SQL_Azure_Perf_Stats_Snapshot_BeforeCapture.txt"
$perfStatsSnapshotScript = ".\SQL_Azure_Perf_Stats_Snapshot.sql"
Write-Host "Intial DB Snapshot running in background..."
Start-Process -NoNewWindow "sqlcmd" "-S $serverFQDN -d $Database -U $fullUsername -P $Password -i $perfStatsSnapshotScript -o $outputFile -w 65535"

$variableArray = 'delayvar="'+$delayString+'"'
$outputFile = ".\output\$($ServerName)_SQL_Azure_Perf_Stats.txt"
$perfStatsScript = ".\SQL_Azure_Perf_Stats.sql"
Write-Host "Capture starting, press Ctrl+C to end"
try {
	sqlcmd -v $variableArray -S $serverFQDN -d $Database -U $fullUsername -P $Password -i $perfStatsScript -o $outputFile -w 65535
} finally {
	Write-Host "Capture finished. You can view the output at $($outputFile)"

	$outputFile = ".\output\$($ServerName)_SQL_Azure_Perf_Stats_Snapshot_Startup_AfterCapture.txt"
	Write-Host "Ending DB Snapshot running in background..."
	Start-Process -NoNewWindow "sqlcmd" "-S $serverFQDN -d $Database -U $fullUsername -P $Password -i $perfStatsSnapshotScript -o $outputFile -w 65535"
}