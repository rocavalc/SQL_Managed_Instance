# SQL Azure Perf Stats
Follow the instructions below to collect Perf Stats script output from your Sql Azure database

## Prerequisites
- Sql login that has access to both the user database and master database
- Name of your database server, provided without .database.windows.net to the script
- Verify your system has SQL Server tools installed. specifically sqlcmd.exe should be available. In the command line, type sqlcmd.exe. if it says "is not recognized as an internal or external command", you need to locate sqlcmd.exe and add it to path environement variable.

## To Use

1. Unzip sql-azure-perf-stats.zip

2. After unzipping the files, you should see the following files apart from this README
	- PerfStats.ps1
	- SQL_Azure_Perf_Stats.sql

3. Open PowerShell and cd to the directory you unzipped the files

4. So that you can run the script run and confirm the change
`Set-Executionpolicy -Scope CurrentUser -ExecutionPolicy UnRestricted`

5. When issue occurs, run PerfStats.ps1 from PowerShell:
`.\PerfStats.ps1` and follow the prompts or:
`.\PerfStats.ps1 -ServerName <servername> -Database <databasename> -Username <username> -Password <password>`
Example: .\PerfStats.ps1 -ServerName "miserver.public.780027d24wda.database.windows.net,3342" -Database "adventureworks" -Username "sqladmin" -Password "PaSSword1"

Optionally you can use -DelayInSeconds <numberofseconds> to change how often the script gathers data.

6. Press Ctrl+C to end the data collection process

7. Afterwards you will have an output folder containing <servername>_SQL_Azure_Perf_Stats.txt
